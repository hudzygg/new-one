// Dummy file to work around a webpack hot reloading bug.
export const a = 1
